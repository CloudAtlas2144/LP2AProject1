public enum Color {
    RED, BLUE, GREEN;
}
